package com.example.usersmicroservice.Entities;

public record UserEntity(long id, String username, String password) {
}

